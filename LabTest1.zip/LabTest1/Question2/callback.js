const resolvedPromise = () =>
  new Promise((resolve, reject) => {
    setTimeout(
        resolve({ message: "Promise resolved" }), 500);
  });

const rejectPromise = () =>
  new Promise((resolve, reject) => {
    setTimeout(
        reject({ error: "Promise rejected" }), 500);
    });


// resolve and handle promise
resolvedPromise().then((message) => console.log(message));

rejectPromise().catch((message) => console.error(message));



