const fs = require("fs");

const removeLogs = () => {
    const logDir = "./logs";
    if (fs.existsSync(logDir)) {
      process.chdir(logDir);
      fs.readdir(process.cwd(), (err, files) => {
        files.forEach((file) => {
          fs.unlink(file, (err) => {
          if (err){
                console.log(`Error deleting file '${file}'`)
            }else{
                console.log(`Deleting file '${file}'`)
            }
        });
        });
      });
    }
  };

  removeLogs()