
const lowerCased = (mixedArray) => {

    return new Promise((resolve, reject) => {

        // check if recived paramater is a valid array 
        if(Array.isArray(mixedArray) == true){
            const filteredArr = mixedArray.filter((arrIndex) => typeof arrIndex === 'string');
  
            const lowerCasedArr = filteredArr.map((x) =>
                x.toLowerCase()
            );
  
            resolve(lowerCasedArr);
        }else {
            reject("array passed into function not valid");
        }
    });
  };
  
 
  const mixedArray = ["PIZZA", 10, true, 25, false, 'Wings'];
  
 
  lowerCased(mixedArray)
    .then((value) =>
      console.log(value)
    )
    .catch((error) =>
      console.log(error)
    );