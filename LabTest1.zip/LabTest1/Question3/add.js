const fs = require("fs");


const createLogs = () => {
    const logDir = "./logs";
    // check if log directory already been created
    if (!fs.existsSync(logDir)) {
      fs.mkdirSync(logDir);
    }
    process.chdir(logDir);
    for (let i = 0; i < 10; i++) {
      fs.writeFile(`log${i+ 1}.txt`, `Log Created file number: ${i+1}`, (err) => {
        if (err){
        console.error(`Error creating file 'log${i+ 1}.txt'`)
        }else{
          console.log(`Creating file 'log${i+ 1}.txt'`)
        }
      });
    }
  };

  createLogs()

  